This sample shows how to work with the dvr-ms files created when working with SBE.  It produces 
a command line utility that has the following options:

Usage : DvrMsCutter.exe Source Destination StartTime EndTime

Source : must be an existing dvr-ms file
Destination : the result dvr-ms file (warning : overwitten if already exist)
StartTime : the start time the source file in this format : hh:mm:ss
EndTime : the end time the source file in this format : hh:mm:ss

