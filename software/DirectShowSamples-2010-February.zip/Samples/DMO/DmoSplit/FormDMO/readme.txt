FormDmo - This code exercises the DMOSplit sample code.

This rather sample shows how to build a graph using the DMOSplit DMO.  It connects either
the left or the right channel of a stereo input file to the audio renderer.