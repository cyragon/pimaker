---------------------------------------------------------------------
VmrSnapper

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

VmrSnapper is an example of how to get a Bitmap from a video using VMR9.

This sample uses the following DirectShow Interfaces :

	IFilterGraph2
	IMediaControl
	IBaseFilter
	IVMRWindowlessControl9
	IVMRFilterConfig9

This sample is based on the BitmapMixer sample.