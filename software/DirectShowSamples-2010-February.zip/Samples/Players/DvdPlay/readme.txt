---------------------------------------------------------------------
DVDPlay

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

A sample dvd player.  

This is NOT a fully featured dvd player app.  However, it
does show the basic.  If you need more functionality, check out the msdn docs
(Currently at http://msdn.microsoft.com/library/default.asp?url=/library/en-us/directshow/htm/dvdapplications.asp).