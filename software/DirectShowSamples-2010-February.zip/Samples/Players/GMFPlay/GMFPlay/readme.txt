---------------------------------------------------------------------
GMFPlay

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

---------------------------------------------------------------------

This sample shows how to play media files one after another without a 
gap between them.

This sample is a fairly direct translation of the GMFPlay sample from 
http://www.gdcl.co.uk.  You MUST download and install the GMFBridge DLL 
from that website before this sample will run.

