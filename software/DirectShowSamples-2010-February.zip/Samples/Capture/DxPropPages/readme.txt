---------------------------------------------------------------------
DxPropPages

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  
---------------------------------------------------------------------

This sample uses DirectShow to preview video, as well as capturing and compressing
video in realtime. This sample also demonstrates the use of property pages.