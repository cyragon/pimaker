This sample shows how the DesCombineLib (written in c#) can be called from a vb program.  The 
code is simple (and a true VB programmer would probably call it ugly), but it shows the basics.

See the DesCombine.chm for a description of all the methods in the lib.