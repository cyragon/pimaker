using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("TestCombine")]
[assembly: AssemblyDescription("Test application for DESCombine library")]
[assembly: AssemblyCompany("http://DirectShowNet.SourceForge.net")]
[assembly: AssemblyProduct("DirectShowLib")]
[assembly: AssemblyCopyright("Public Domain")]

[assembly: AssemblyVersion("1.0.*")]
