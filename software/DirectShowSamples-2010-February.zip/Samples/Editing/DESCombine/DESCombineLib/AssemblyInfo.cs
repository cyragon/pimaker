using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("DESCombine")]
[assembly: AssemblyDescription("Library for combining video files")]
[assembly: AssemblyCompany("http://DirectShowNet.SourceForge.net")]
[assembly: AssemblyProduct("DirectShowLib")]
[assembly: AssemblyCopyright("Public Domain")]

[assembly: AssemblyVersion("1.0.*")]
